#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 12 18:25:17 2021

@author: joseleiva
"""
from __future__ import division

#Import all the metrics to evaluate the accuracy of the N4SID Algorithm with the selected order 

from sklearn.metrics import r2_score
from sklearn.metrics import median_absolute_error
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.metrics import mean_squared_error


from past.utils import old_div

# Checking path to access other files
try:
    from sippy import *
except ImportError:
    import sys, os

    sys.path.append(os.pardir)
    from sippy import *
import matplotlib.pyplot as plt
import numpy as np
from sippy import functionset as fset
from sippy import functionsetSIM as fsetSIM
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('science')

data = pd.read_csv("SOM3-N4SID-NONRECURSIVE-TRAINING_AND_TEST.csv") # dataset from January to January 12 months
data = data.drop_duplicates(subset=['Time'])

df=pd.DataFrame(data)
df.mean();
df=df.fillna(df.mean())

#MODEL 1 of N4SID: FIRST 4 MONTHS OF THE DATASET (JAN-FEB-MARCH-)

print (df)
m=df.shape[0]

starting_month=11; # 1=JANUARY, 2=FEBRUARY, 3=MARCH..., 12= DECEMBER #
months_offset=0+(starting_month-1);
#week_number=0;

offset=((months_offset)*4.3);

#47095
k=2*4.3; #number of weeks of data for the estimationand training the N4SID 
f=0.38; # number of estimated weeks with the N4SID algorithm

w_y=2*52;  # Number of weeks during the year 
j=int((w_y-k-offset)/(f));


for p in range (1):

    i=p;
    print("Model number: ",i)
    t_0=int(i*4.3*m/w_y)+int(offset*m/w_y);
    t_1=t_0+int(m*k/w_y);
    t_2=t_1+int(m*f/w_y);
    

    df1=df.iloc[t_0:t_1];
    df1_test =df.iloc[t_1:t_2];
#
    df1=df1.fillna(df1.mean())
    df1_test=df1_test.fillna(df1_test.mean())
#    print(df1)
#    print(df1_test)
##
##
    Time1 = np.array([df1['Time'].values.tolist()])
    Time_months1=Time1/24/3600/30;
##
    Time1_test = np.array([df1_test['Time'].values.tolist()])
    Time_months1_test=Time1_test/24/3600/30;

## Definition of the Inputs Vector. Training dataset
    
    
    U1=[
        df1['mod.weaBus.TDryBul'].values.tolist(),
        df1['mod.weaBus.HGloHor'].values.tolist(),
#        df1['mod.weaBus.TBlaSky'].values.tolist(),
        df1['P1_OccN'].values.tolist(),
        df1['P1_IntGaiTot'].values.tolist(),
#        df1['mod.weaBus.winSpe'].values.tolist(),
        

        df1['senHeaPow1_y'].values.tolist(),
#        df1['senCCPow1_y'].values.tolist(),

#        df1['mod.HVAC1.controls.outHeaSet'].values.tolist(),


        df1['senFanPow1_y'].values.tolist(),
        df1['senOAVol1_y'].values.tolist(),
#        df1['senRH1_y'].values.tolist(),
#        df1['senFanVol1_y'].values.tolist()

            ]


    U1_test=[
             df1_test['mod.weaBus.TDryBul'].values.tolist(),
             df1_test['mod.weaBus.HGloHor'].values.tolist(),
#             df1_test['mod.weaBus.TBlaSky'].values.tolist(),
             df1_test['P1_OccN'].values.tolist(),
             df1_test['P1_IntGaiTot'].values.tolist(),
#             df1_test['mod.weaBus.winSpe'].values.tolist(),

             df1_test['senHeaPow1_y'].values.tolist(),
#             df1_test['senCCPow1_y'].values.tolist(),

#             df1_test['mod.HVAC1.controls.outHeaSet'].values.tolist(),

#
             df1_test['senFanPow1_y'].values.tolist(),
             df1_test['senOAVol1_y'].values.tolist(),
#             df1_test['senRH1_y'].values.tolist(),
#             df1_test['senFanVol1_y'].values.tolist()
             

             
                             
             
             
             
             
             ]

 
    U_1=np.array(U1);
    U_1_test=np.array(U1_test);
##

    y_tot1= [df1['senTRoom1_y'].values.tolist()]
    y_tot1=np.array(y_tot1)


    y_tot1_test= [df1_test['senTRoom1_y'].values.tolist()]
    y_tot1_test=np.array(y_tot1_test)
##
###System identification
#            
    method = 'N4SID'
    sys_id1 = system_identification(y_tot1, U_1, method, SS_fixed_order=7)
    
#print(sys_id1)
#SS_fixed_order=7
#    SS_fixed_order=5
    sys_id1.x2=np.array((
            [2.46448],[-2.80786],[0.435631],[0.754336],[-3.03051],[-3.59742],[10.7656]

            ))
    








    
    xid1_train, yid1_train = fsetSIM.SS_lsim_predictor_form(sys_id1.A_K, sys_id1.B_K, sys_id1.C, sys_id1.D,sys_id1.K,y_tot1, U_1,sys_id1.x2)
#    print(xid1_train,yid1_train) 
#
#
#
    a=xid1_train[0,len(xid1_train[0])-1];
    b=xid1_train[1,len(xid1_train[0])-1];
    c=xid1_train[2,len(xid1_train[0])-1];
    d=xid1_train[3,len(xid1_train[0])-1];
    e=xid1_train[4,len(xid1_train[0])-1];
    f=xid1_train[5,len(xid1_train[0])-1];
    g=xid1_train[6,len(xid1_train[0])-1];
#    h=xid1_train[7,len(xid1_train[0])-1];
#    i=xid1_train[8,len(xid1_train[0])-1];
#    l=xid1_train[9,len(xid1_train[0])-1];
#    n=xid1_train[10,len(xid1_train[0])-1];
#    o=xid1_train[11,len(xid1_train[0])-1];
#    q=xid1_train[12,len(xid1_train[0])-1];

    
#    # TRY ORDER=1
#    sys_id1.x1=np.array([[a]]) 
    ## TRY ORDER=2
#    sys_id1.x1=np.array([[a],[b]]) 
    ## TRY ORDER=3
#    sys_id1.x1=np.array([[a],[b],[c]])
    ## TRY ORDER=4
#    sys_id1.x1=np.array([[a],[b],[c],[d]])
    ## TRY ORDER=5
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e]])
    ## TRY ORDER=6
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f]])
    ## TRY ORDER=7
    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f],[g]]);   
    ## TRY ORDER=8
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f],[g],[h]])        
    ## TRY ORDER=9
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f],[g],[h],[i]])     
    ## TRY ORDER=10
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f],[g],[h],[i],[l]])       
    ## TRY ORDER=11
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f],[g],[h],[i],[l],[n]])
    ## TRY ORDER=12
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f],[g],[h],[i],[l],[n],[o]])  
    ## TRY ORDER=13
#    sys_id1.x1=np.array([[a],[b],[c],[d],[e],[f],[g],[h],[i],[l],[n],[o],[q]])  
       
#    xid1_test, yid1_test = fsetSIM.SS_lsim_process_form(sys_id1.A, sys_id1.B, sys_id1.C, sys_id1.D, U_1_test,sys_id1.x0)
  
    x_1=sys_id1.x1;
    
    xid1_test, yid1_test = fsetSIM.SS_lsim_process_form(sys_id1.A, sys_id1.B, sys_id1.C, sys_id1.D, U_1_test,sys_id1.x1)

#    print(xid1_test,yid1_test)
    

#    #Calculate and analyze the errors
#    
#    error1_test=(yid1_test-y_tot1_test)/y_tot1_test*100;
##
#    plt.figure()
#    plt.plot(Time_months1_test[0,0:t_2-t_1],error1_test[0,0:t_2-t_1]);
#    plt.ylabel("Percentage error (%)")
#    plt.grid()
#    plt.title("Percentage error of the indoor air temperature estimation of core zone")
#    plt.xlabel("Time (months)")
##    plt.show()
#    
#   
#    plt.figure()
#    plt.hist(error1_test[0]);
#    plt.ylabel("Number of Observations")
#
#    plt.ylabel("Indoor Air Temperature (ºC)")
#    plt.grid()
#    plt.xlabel("Time (months)") 
##    plt.show()
#
    ##Calculate the metrics 
    #Results of Temperature estimation of core zone
    
#    mae_core=median_absolute_error(y_tot1_test[0,0:t_2-t_1],yid1_test[0,0:t_2-t_1]);
#    mape_core= mean_absolute_percentage_error(y_tot1_test[0,0:t_2-t_1],yid1_test[0,0:t_2-t_1]);
#    mse_core=mean_squared_error(y_tot1_test[0,0:t_2-t_1],yid1_test[0,0:t_2-t_1]);
#    r2_core=r2_score(yid1_test[0,0:t_2-t_1], y_tot1_test[0,0:t_2-t_1]);
#    print("Determination Coefficient: ")
#    print(r2_core)
    
    
#    #Results of Temperature estimation of zone 1
    
    mae_z1=median_absolute_error(y_tot1_test[0,0:t_2-t_1],yid1_test[0,0:t_2-t_1]);
    mape_z1= mean_absolute_percentage_error(y_tot1_test[0,0:t_2-t_1],yid1_test[0,0:t_2-t_1]);
    mse_z1=mean_squared_error(y_tot1_test[0,0:t_2-t_1],yid1_test[0,0:t_2-t_1]);
    r2_z1=(r2_score(yid1_test[0,0:t_2-t_1], y_tot1_test[0,0:t_2-t_1]));
    
    print(r2_z1)
    
##    #Results of Temperature estimation of zone 2
#    
#    mae_z2=median_absolute_error(y_tot1_test[2,0:t_2-t_1],yid1_test[2,0:t_2-t_1]);
#    mape_z2= mean_absolute_percentage_error(y_tot1_test[2],yid1_test[2,0:t_2-t_1]);
#    mse_z2=mean_squared_error(y_tot1_test[2],yid1_test[2,0:t_2-t_1]);
#    r2_z2=(r2_score(yid1_test[2,0:t_2-t_1], y_tot1_test[2,0:t_2-t_1]));
#    
#    print(r2_z2)
#    
#    
##    #Results of Temperature estimation of zone 3
##    
#    
#    mae_z3=median_absolute_error(y_tot1_test[3,0:t_2-t_1],yid1_test[3,0:t_2-t_1]);
#    mape_z3= mean_absolute_percentage_error(y_tot1_test[3],yid1_test[3,0:t_2-t_1]);
#    mse_z3=mean_squared_error(y_tot1_test[3,0:t_2-t_1],yid1_test[3,0:t_2-t_1]);
#    r2_z3=(r2_score(yid1_test[3,0:t_2-t_1], y_tot1_test[3,0:t_2-t_1]));
#    
#    print(r2_z3)
#    
##    #Results of Temperature estimation of zone 4
##    
#    
#    mae_z4=median_absolute_error(y_tot1_test[4,0:t_2-t_1],yid1_test[4,0:t_2-t_1]);
#    mape_z4= mean_absolute_percentage_error(y_tot1_test[4,0:t_2-t_1],yid1_test[4,0:t_2-t_1]);
#    mse_z4=mean_squared_error(y_tot1_test[4,0:t_2-t_1],yid1_test[4,0:t_2-t_1]);
#    r2_z4=(r2_score(yid1_test[4,0:t_2-t_1], y_tot1_test[4,0:t_2-t_1]));
#    
#    print(r2_z4)
    
##  
    print("Mean Absolute Errors: ")
#    print(mae_core)
    print(mae_z1)
#    print(mae_z2)
#    print(mae_z3)
#    print(mae_z4)
    #PLots of Temperature estimation of Core zone
    #
    print("Mean Square Errors: ")
#    print(mse_core)
    print(mse_z1)
#    print(mse_z2)
#    print(mse_z3)
#    print(mse_z4)    
    
#    y_values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,13,14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,26]
#    text_values = ["February1", "March1", "April1","May1", "June1", "July1", "August1","September1", "October1", "November1", "December1", "January2","February2", "March2", "April2","May2", "June2", "July2", "August2","September2", "October2", "November2", "December2", "January3"]
#    x_values = np.arange(1, len(text_values) + 1, 1)
    
    
#    plt.figure()
#    plt.plot(Time_months1_test[0,0:t_2-t_1], y_tot1_test[0,0:t_2-t_1]-273.15,linewidth=3, color='forestgreen')
#    plt.plot(Time_months1_test[0,0:t_2-t_1], yid1_test[0,0:t_2-t_1]-273.15, linestyle='dashed',linewidth=1.5, color='lightgreen')
#    plt.plot(Time_months1[0,2:t_1-t_0], y_tot1[0,2:t_1-t_0]-273.15,linewidth=3, color='steelblue')
#    plt.plot(Time_months1[0,2:t_1-t_0], yid1_train[0,2:t_1-t_0]-273.15, linestyle='dashed',linewidth=1.5, color='cyan')
#    plt.ylabel("Indoor Air Temperature (ºC)",size=16)
#    plt.grid()
#    plt.xlabel("Time (months)",size=10)
#    #
##    plt.text(1, 10, "R2=",r2_core,size=18)
#    plt.yticks(size=16)
#    plt.xticks(x_values, text_values,size=10)
#    plt.title("Comparison of original data and the output of the N4SID model. CORE ZONE",size=20)
#    plt.legend(['Original system Testing', 'Identified system Testing, ' + method,'Original System Training',  'Identified system Training, ' + method])
##    positions = (0, 1, 2, 3, 4)
##    labels = ("January", "February", "March", "April","May")
##    plt.xticks(positions, labels)
#    plt.ylim([15, 27])
#    plt.show()
#    
#    plt.figure()
#    plt.plot(Time_months1[0], U1[7],linewidth=3, color='darkorange')
#    plt.ylabel("Thermal Power (W)",size=12)
#    plt.grid()
#    plt.xlabel("Time (months)",size=12)
#    #
##    plt.text(1, 10, "R2=",r2_core,size=18)
#    plt.yticks(size=12)
#    plt.xticks(x_values, text_values,size=12)
#    plt.title("Evolution of the thermal power of CORE ZONE",size=20)
##    plt.legend(['Original system Testing', 'Identified system Testing, ' + method,'Original System Training',  'Identified system Training, ' + method])
##    positions = (0, 1, 2, 3, 4)
##    labels = ("January", "February", "March", "April","May")
##    plt.xticks(positions, labels)
##    plt.ylim([15, 27])
#    plt.show()
#    #PLots of Temperature estimation of Zone 1
#    #
#    
    plt.figure()
    plt.plot(Time_months1_test[0,0:t_2-t_1], y_tot1_test[0,0:t_2-t_1]-273.15,linewidth=3, color='forestgreen')
    plt.plot(Time_months1_test[0,0:t_2-t_1], yid1_test[0,0:t_2-t_1]-273.15, linestyle='dashed',linewidth=1.5, color='lightgreen')
    plt.plot(Time_months1[0,2:t_1-t_0], y_tot1[0,2:t_1-t_0]-273.15,linewidth=3, color='steelblue')
    plt.plot(Time_months1[0,2:t_1-t_0], yid1_train[0,2:t_1-t_0]-273.15, linestyle='dashed',linewidth=1.5, color='cyan')
    plt.ylabel("Indoor Air Temperature (ºC)",size=18)
    plt.grid()
    plt.xlabel("Time (months)",size=10)
    #
    plt.yticks(size=18)
#    plt.xticks(x_values, text_values,size=10)
    plt.xticks(size=10)
    plt.title("Comparison of original data and the output of the N4SID model. ZONE 1",size=20)
    plt.legend(['Original system Testing', 'Identified system Testing, ' + method,'Original System Training',  'Identified system Training, ' + method])
#    positions = (0, 1, 2, 3, 4)
#    labels = ("January", "February", "March", "April","May")
#    plt.xticks(positions, labels)
    plt.ylim([0, 40])
    plt.show()
#    
#    #PLots of Temperature estimation of Zone 2
#    #
#    
#    plt.figure()
#    plt.plot(Time_months1_test[0,0:t_2-t_1], y_tot1_test[2,0:t_2-t_1]-273.15,linewidth=3, color='forestgreen')
#    plt.plot(Time_months1_test[0,0:t_2-t_1], yid1_test[2,0:t_2-t_1]-273.15, linestyle='dashed',linewidth=1.5, color='lightgreen')
#    plt.plot(Time_months1[0,2:t_1-t_0], y_tot1[2,2:t_1-t_0]-273.15,linewidth=3, color='steelblue')
#    plt.plot(Time_months1[0,2:t_1-t_0], yid1_train[2,2:t_1-t_0]-273.15, linestyle='dashed',linewidth=1.5, color='cyan')
#    plt.ylabel("Indoor Air Temperature (ºC)",size=12)
#    plt.grid()
#    plt.xlabel("Time (months)",size=12)
#    #
#    plt.title("Comparison of original data and the output of the N4SID model. ZONE 2",size=20)
#    plt.legend(['Original system Testing', 'Identified system Testing, ' + method,'Original System Training',  'Identified system Training, ' + method])
##    positions = (0, 1, 2, 3, 4)
##    labels = ("January", "February", "March", "April","May")
##    plt.xticks(positions, labels)
#    plt.yticks(size=12)
#    plt.xticks(x_values, text_values,size=12)
#    plt.ylim([15, 27])
#    plt.show()
#    #PLots of Temperature estimation of Zone 3
#    #
#    
#    plt.figure()
#    plt.plot(Time_months1_test[0,0:t_2-t_1], y_tot1_test[3,0:t_2-t_1]-273.15,linewidth=3, color='forestgreen')
#    plt.plot(Time_months1_test[0,0:t_2-t_1], yid1_test[3,0:t_2-t_1]-273.15, linestyle='dashed',linewidth=1.5, color='lightgreen')
#    plt.plot(Time_months1[0,2:t_1-t_0], y_tot1[3,2:t_1-t_0]-273.15,linewidth=3, color='steelblue')
#    plt.plot(Time_months1[0,2:t_1-t_0], yid1_train[3,2:t_1-t_0]-273.15, linestyle='dashed',linewidth=1.5, color='cyan')
#    plt.ylabel("Indoor Air Temperature (ºC)",size=12)
#    plt.grid()
#    plt.xlabel("Time (months)",size=12)
#    #
#    plt.yticks(size=12)
#    plt.xticks(x_values, text_values,size=12)
#    plt.title("Comparison of original data and the output of the N4SID model. ZONE 3",size=20)
#    plt.legend(['Original system Testing', 'Identified system Testing, ' + method,'Original System Training',  'Identified system Training, ' + method])
##    positions = (0, 1, 2, 3)
##    labels = ("January", "February", "March", "April")
##    plt.xticks(positions, labels)
#    plt.ylim([15, 27])
#    plt.show()
#    
#    #PLots of Temperature estimation of Zone 4
#    #
#    
#    plt.figure()
#    plt.plot(Time_months1_test[0,0:t_2-t_1], y_tot1_test[4,0:t_2-t_1]-273.15,linewidth=3, color='forestgreen')
#    plt.plot(Time_months1_test[0,0:t_2-t_1], yid1_test[4,0:t_2-t_1]-273.15, linestyle='dashed',linewidth=1.5, color='lightgreen')
#    plt.plot(Time_months1[0,4:t_1-t_0], y_tot1[4,4:t_1-t_0]-273.15,linewidth=3, color='steelblue')
#    plt.plot(Time_months1[0,4:t_1-t_0], yid1_train[4,4:t_1-t_0]-273.15, linestyle='dashed',linewidth=1.5, color='cyan')
#    plt.ylabel("Indoor Air Temperature (ºC)",size=18)
#    plt.grid()
#    plt.xlabel("Time (months)",size=12)
#    #
#    plt.yticks(size=12)
#    plt.xticks(x_values, text_values,size=12)
#    plt.title("Comparison of original data and the output of the N4SID model. ZONE 4",size=20)
#    plt.legend(['Original system Testing', 'Identified system Testing, ' + method,'Original System Training',  'Identified system Training, ' + method])
##    positions = (0, 1, 2, 3, 4)
##    labels = ("January", "February", "March", "April","May")
##    plt.xticks(positions, labels)
#    plt.ylim([15, 27])
#    plt.show()
    f=int(1);
#
# MODELS FINISHED. NOW THE METRICS AND MATRICES ARE SAVED 


#metrics_zcore=np.array([mae_core,mape_core,mse_core,r2_core])
#metrics_z1=np.array([mae_z1,mape_z1,mse_z1,r2_z1])
#metrics_z2=np.array([mae_z2,mape_z2,mse_z2,r2_z2])
#metrics_z3=np.array([mae_z3,mape_z3,mse_z3,r2_z3])
#metrics_z4=np.array([mae_z4,mape_z4,mse_z4,r2_z4])
#
#
#np.save('metrics_core_zone.npy', metrics_zcore)
#np.save('metrics_zone_1.npy', metrics_z1)
#np.save('metrics_zone_2.npy', metrics_z2)
#np.save('metrics_zone_3.npy', metrics_z3)
#np.save('metrics_zone_4.npy', metrics_z4)
#
#Estimated_T=yid1_test;
#
#plt.figure()
#plt.hist(error1_test[0]);
#plt.ylabel("Number of Observations")
#plt.grid()
#plt.title("Histogram of Estimation Errors. Core Zone Temperature")
#plt.xlabel("Percentage Errors (%)")
#plt.show()

 #SAVE THE OUTPUTS OF THE BOTH MODELS


#metrics=np.array([metrics_zcore, metrics_z1, metrics_z2, metrics_z3, metrics_z4])
#
#
##titles = ("Core Zone", "Zone 1", "Zone 2", "Zone 3","Zone 4")
#np.savetxt("moving_model.csv", metrics, header="MAE, MAPE, MSE, R2",delimiter=",")
#
#
# GET ALL MATRICES 
A1=sys_id1.A

B1=sys_id1.B

C1=sys_id1.C

D1=sys_id1.D


# GET ALL KALMAN GAINS  

K1=sys_id1.K


# GET ALL KALMAN MATRICES A_K AND B_K 

KA1=sys_id1.A_K

KB1=sys_id1.B_K

#
# #SAVE ALL MATRICES 
# 
np.save('matrix_A1.npy', A1)

np.save('matrix_B1.npy', B1)

np.save('matrix_C1.npy', C1)

np.save('matrix_D1.npy', D1)
#
#
# #SAVE ALL KALMAN GAINS 
# 
#  
np.save('matrix_K1.npy', K1)
#
#
# #SAVE ALL KALMAN MATRICES A_K B_K 
# 
#  
np.save('matrix_AK1.npy', KA1)

np.save('matrix_BK1.npy', KB1)

# #SAVE THE INITIAL STATE FOR THE TESTING SCRIPT

np.save('x1.npy', x_1)
#
